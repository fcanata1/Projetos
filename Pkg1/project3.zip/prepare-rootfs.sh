#!/bin/sh

# Script POSIX para preparar rootfs LFS x86_64 em /mnt/rootfs
# Pré-requisitos: /mnt/rootfs montado vazio, internet ativa para downloads posteriores

set -e  # Sai em erro

ROOTFS=/mnt/rootfs
TOOLS=$ROOTFS/tools
LFS_TGT=x86_64-lfs-linux-gnu
HOST=$(uname -m)-$(uname -m)-linux-gnu  # Prefixo cross-compiler

# Verificações iniciais
if [ ! -d "$ROOTFS" ]; then
    echo "ERRO: $ROOTFS não existe ou não é diretório." >&2
    exit 1
fi
if [ "$(id -u)" != "0" ]; then
    echo "ERRO: Execute como root." >&2
    exit 1
fi

# Limpa rootfs se não vazio
if [ "$(ls -A $ROOTFS 2>/dev/null)" ]; then
    echo "AVISO: Limpando $ROOTFS..."
    rm -rf $ROOTFS/*
fi

# Cria estrutura FHS mínima
mkdir -p $ROOTFS/{dev/{pts,shm},proc,sys,run,tmp,var{,/tmp},boot,etc,home/lfs,usr/{bin,sbin,lib{,64},include,share/{info,man,config.site}},opt,root,srv,mnt}

# /etc/passwd e group
cat > $ROOTFS/etc/passwd << EOF
root:x:0:0:root:/root:/bin/bash
lfs:x:1000:1000:lfs:/home/lfs:/bin/bash
EOF

cat > $ROOTFS/etc/group << EOF
root:x:0:
bin:x:1:
sys:x:2:
kmem:x:3:
tty:x:4:
tape:x:5:
daemon:x:6:
floppy:x:7:
disk:x:8:
lp:x:9:
dialout:x:10:
audio:x:11:
video:x:12:
utmp:x:13:
usb:x:14:
cdrom:x:15:
lfs:x:1000:
EOF

# /etc/fstab
cat > $ROOTFS/etc/fstab << EOF
devtmpfs    /dev     devtmpfs rw,nosuid 0 0
proc        /proc    proc     rw,nosuid 0 0
sysfs       /sys     sysfs    rw,nosuid 0 0
devpts      /dev/pts devpts   rw,nosuid,gid=4,mode=620 0 0
tmpfs       /run     tmpfs    rw,nosuid,nr_inodes=0,size=10%,mode=755 0 0
tmpfs       /tmp     tmpfs    rw,nosuid,nodev,size=2G 0 0
EOF

# /etc/hosts
cat > $ROOTFS/etc/hosts << EOF
127.0.0.1\tlocalhost
::1\t\tlocalhost ip6-localhost ip6-loopback
EOF

# CONTINUAÇÃO do config.site ATÉ O FIM:

# 4. CONFIG.SITE (evita contaminação host)
cat > "$ROOTFS/usr/share/config.site" << 'EOF'
ac_cv_func_realloc_0_nonnull=yes
ac_cv_func_malloc_0_nonnull=yes
EOF

# 5. PERMISSÕES E LINKS FHS
chmod 755 "$ROOTFS"/{usr/{bin,sbin,lib{,64},share},boot,home/lfs,opt,mnt,srv,var}
chmod 1777 "$ROOTFS"/{tmp,var/tmp}
chmod 700 "$ROOTFS"/root
chown root:root "$ROOTFS"/{root,var,etc,usr/{bin,lib{,64},sbin,share}}

ln -sf usr/lib "$ROOTFS/lib"
ln -sf usr/bin "$ROOTFS/bin" 
ln -sf usr/sbin "$ROOTFS/sbin"

# 6. USUÁRIO LFS
if ! id lfs >/dev/null 2>&1; then
    groupadd lfs
    useradd -s /bin/bash -m -g lfs -u 1000 lfs
fi
mkdir -p "$ROOTFS/sources"
chown -R lfs:lfs "$ROOTFS"/{sources,home/lfs}

# 7. AMBIENTE LFS
su - lfs << 'LFS_EOF'
cat > ~/.bashrc << 'BASHRC'
set +h
umask 022
LFS=/mnt/rootfs
LC_ALL=POSIX
LFS_TGT=x86_64-lfs-linux-gnu
PATH=/usr/bin:$LFS/tools/bin
CONFIG_SITE=$LFS/usr/share/config.site
export LFS LC_ALL LFS_TGT PATH CONFIG_SITE
MAKEFLAGS='-j$(nproc)'
BASHRC
source ~/.bashrc
LFS_EOF

# 8. MOUNTS
mount --bind /dev "$ROOTFS/dev"
mount -t proc proc "$ROOTFS/proc"
mount -t sysfs sysfs "$ROOTFS/sys" 
mount -t tmpfs tmpfs "$ROOTFS/run"

# 9. SCRIPT CHROOT
cat > /usr/local/bin/chroot-lfs << 'CHROOT'
#!/bin/sh
[ "$1" = "--clean" ] && { umount -R /mnt/rootfs/{dev,proc,sys,run} 2>/dev/null||true; exit; }
chroot /mnt/rootfs /bin/bash --login +h -c 'export PS1="(lfs) $ "; exec bash'
CHROOT
chmod +x /usr/local/bin/chroot-lfs

echo "✅ PRONTO! Execute: su - lfs && chroot-lfs"