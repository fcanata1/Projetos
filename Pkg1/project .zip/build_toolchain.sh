#!/bin/sh

# Script POSIX para criar toolchain x86_64 glibc temporária
# Instala em /mnt/rootfs/tools com binutils, gcc, glibc latest
set -e

TARGET="/mnt/rootfs/tools"
PARALLEL=$(nproc)

echo "Criando toolchain x86_64-glibc em $TARGET..."

# 1. Preparar diretório
rm -rf "$TARGET"
mkdir -p "$TARGET/src" "$TARGET/install"

cd "$TARGET/src"

# 2. Baixar e compilar binutils latest (ex: 2.44)
wget https://ftp.gnu.org/gnu/binutils/binutils-2.44.tar.xz
tar xf binutils-2.44.tar.xz
cd binutils-2.44
./configure --prefix="$TARGET/install" --target=x86_64-pc-linux-gnu --disable-nls
make -j$PARALLEL && make install
cd ..

# 3. Headers Linux kernel (latest stable)
wget https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-6.12.tar.xz
tar xf linux-6.12.tar.xz
cp -r linux-6.12/include "$TARGET/install/x86_64-pc-linux-gnu"

# 4. GCC latest (ex: 14.2.0) com glibc
wget https://ftp.gnu.org/gnu/gcc/gcc-14.2.0/gcc-14.2.0.tar.xz
tar xf gcc-14.2.0.tar.xz
cd gcc-14.2.0

# Baixar dependências prereqs
./contrib/download_prerequisites

mkdir build && cd build
../configure \
  --prefix="$TARGET/install" \
  --target=x86_64-pc-linux-gnu \
  --enable-languages=c,c++ \
  --disable-multilib \
  --with-sysroot="$TARGET/install/x86_64-pc-linux-gnu" \
  --disable-nls

make -j$PARALLEL all-gcc all-target-libgcc && make install-gcc install-target-libgcc
cd ../..

# 5. Glibc latest (ex: 2.41)
wget https://ftp.gnu.org/gnu/glibc/glibc-2.41.tar.xz
tar xf glibc-2.41.tar.xz
mkdir glibc-build && cd glibc-build
../glibc-2.41/configure \
  --prefix="$TARGET/install/x86_64-pc-linux-gnu/sysroot/usr"
make -j$PARALLEL && make install
cd ..

# 6. Testar toolchain
echo "Testando: $TARGET/install/bin/x86_64-pc-linux-gnu-gcc --version"
"$TARGET/install/bin/x86_64-pc-linux-gnu-gcc" -v

echo "Toolchain pronta em $TARGET!"
echo "Adicione ao PATH: export PATH=$PATH:$TARGET/install/bin"