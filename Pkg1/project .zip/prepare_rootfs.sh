#!/bin/sh

# Script POSIX para preparar rootfs e setar variáveis para build
set -e

ROOTFS="/mnt/rootfs"
TOOLS="$ROOTFS/tools"
SYSROOT="$ROOTFS/sysroot"
SRC="$ROOTFS/src"

echo "Preparando rootfs em $ROOTFS..."

# 1. Criar estrutura completa de diretórios
echo "Criando estrutura de diretórios..."
rm -rf "$ROOTFS"
mkdir -p "$ROOTFS"/{bin,sbin,etc,lib,lib64,usr/{bin,sbin,lib,lib64},var,tmp,dev,proc,sys,boot,home,root,mnt,media,opt}
mkdir -p "$TOOLS"/{bin,lib,lib64,include}
mkdir -p "$SYSROOT"/usr/{lib,lib64,include}
mkdir -p "$SRC"

# 2. Criar dispositivos essenciais
echo "Criando dispositivos..."
mknod "$ROOTFS/dev/null"    c 1  3
mknod "$ROOTFS/dev/zero"    c 1  5
mknod "$ROOTFS/dev/console" c 5  1
mknod "$ROOTFS/dev/tty"     c 5  0
mknod "$ROOTFS/dev/random"  c 1  8
mknod "$ROOTFS/dev/urandom" c 1  9
chmod 666 "$ROOTFS/dev"/null "$ROOTFS/dev/zero"
chmod 600 "$ROOTFS/dev/console" "$ROOTFS/dev/tty"

# 3. Arquivos essenciais do sistema
echo "Criando arquivos essenciais..."
cat > "$ROOTFS/etc/passwd" << 'EOF'
root:x:0:0:root:/root:/bin/sh
nobody:x:65534:65534:nobody:/nonexistent:/bin/sh
EOF

cat > "$ROOTFS/etc/group" << 'EOF'
root:x:0:
bin:x:1:
sys:x:2:
kmem:x:3:
tty:x:4:
nobody:x:65534:
EOF

cat > "$ROOTFS/etc/fstab" << 'EOF'
# <file system> <mount point>   <type>  <options>       <dump>  <pass>
proc            /proc           proc    nosuid,noexec   0       0
sysfs           /sys            sysfs   nosuid,noexec   0       0
devpts          /dev/pts        devpts  nosuid,gid=5    0       0
tmpfs           /tmp            tmpfs   defaults        0       0
EOF

# 4. Definir variáveis de ambiente para builds
cat > "$ROOTFS/build_env.sh" << EOF
#!/bin/sh
export ROOTFS="$ROOTFS"
export TOOLS="$TOOLS"
export SYSROOT="$SYSROOT"
export SRC="$SRC"
export PATH="$TOOLS/bin:$PATH"
export CC="$TOOLS/bin/x86_64-pc-linux-gnu-gcc"
export CXX="$TOOLS/bin/x86_64-pc-linux-gnu-g++"
export CFLAGS="--sysroot=$SYSROOT -O2"
export LDFLAGS="--sysroot=$SYSROOT"
export PKG_CONFIG_PATH="$SYSROOT/usr/lib/pkgconfig"
export CROSS_COMPILE="x86_64-pc-linux-gnu-"

echo "Ambiente configurado:"
echo "  ROOTFS: $ROOTFS"
echo "  TOOLS:  $TOOLS"
echo "  SYSROOT: $SYSROOT"
EOF

chmod +x "$ROOTFS/build_env.sh"

# 5. Links simbólicos essenciais
ln -sf lib "$ROOTFS/usr/lib64"
ln -sf lib "$ROOTFS/lib64"
ln -sf bin "$ROOTFS/usr/sbin"
ln -sf bin "$ROOTFS/sbin"

echo "RootFS preparado em $ROOTFS!"
echo ""
echo "Para usar nos scripts de build:"
echo "  source $ROOTFS/build_env.sh"
echo "  # agora use $CC, $CXX, $CFLAGS, etc."
echo ""
echo "Estrutura criada:"
ls -la "$ROOTFS" | head -20