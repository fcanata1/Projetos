#!/bin/sh

# Monitor inteligente SysVinit - start, stop, restart, status, list
# POSIX 100% com cores e validação
ROOTFS="/mnt/rootfs"
INITDIR="$ROOTFS/etc/init.d"

RED='\u001B[0;31m'; GREEN='\u001B[0;32m'; YELLOW='\u001B[1;33m'; NC='\u001B[0m'

log() { echo "${GREEN}[SVC]${NC} $*"; }
warn() { echo "${YELLOW}[SVC]${NC} $*"; }
error() { echo "${RED}[SVC]${NC} $*" >&2; }

# Verificar se serviço existe
service_exists() {
    [ -x "$INITDIR/$1" ]
}

# Status do serviço
status_svc() {
    local svc="$1"
    service_exists "$svc" || { warn "Serviço $svc não existe"; return 1; }
    
    if pgrep -f "$svc" >/dev/null 2>&1; then
        log "$svc: ${GREEN}RODANDO${NC} ($$)"
    else
        warn "$svc: ${RED}PARADO${NC}"
    fi
}

# Executar ação no serviço
action_svc() {
    local svc="$1" action="$2"
    service_exists "$svc" || { error "Serviço $svc não encontrado"; return 1; }
    
    case "$action" in
        start) "$INITDIR/$svc" start ;;
        stop)  "$INITDIR/$svc" stop ;;
        restart) "$INITDIR/$svc" stop; sleep 1; "$INITDIR/$svc" start ;;
        status) status_svc "$svc" ;;
        *) error "Ação inválida: $action (start/stop/restart/status)" ;;
    esac
}

# Listar todos serviços
list_services() {
    echo "${GREEN}Serviços SysVinit:${NC}"
    for svc in "$INITDIR"/*; do
        [ -x "$svc" ] || continue
        svc=$(basename "$svc")
        status_svc "$svc" && echo "  $svc" || echo "  ${YELLOW}$svc${NC}"
    done | column -t
}

# MAIN
case "${1:-help}" in
    list|ls)      list_services ;;
    status|st)    action_svc "$2" status ;;
    start)        action_svc "$2" start && log "✓ $2 iniciado" ;;
    stop)         action_svc "$2" stop && log "⏹ $2 parado" ;;
    restart|rs)   action_svc "$2" restart && log "🔄 $2 reiniciado" ;;
    help|-h|*) 
        echo "Uso: $0 {list|status|start|stop|restart} [serviço]"
        echo "Ex: $0 list"
        echo "   $0 status networking"
        echo "   $0 start httpd"
        ;;
esac