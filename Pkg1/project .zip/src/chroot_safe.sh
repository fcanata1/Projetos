#!/bin/sh

# Script POSIX inteligente para chroot seguro em /mnt/rootfs
# Verifica mounts, configura ambiente, entra/sai limpo
set -e

ROOTFS="/mnt/rootfs"
SHELL="${1:-/bin/busybox sh}"
PIDFILE="/tmp/chroot_$$.pid"

# Cores ANSI POSIX
RED='\u001B[0;31m'
GREEN='\u001B[0;32m'
YELLOW='\u001B[1;33m'
NC='\u001B[0m' # No Color

# Função: Log colorido
log() {
    echo "${GREEN}[OK]${NC} $*" >&2
}

warn() {
    echo "${YELLOW}[AVISO]${NC} $*" >&2
}

error() {
    echo "${RED}[ERRO]${NC} $*" >&2
    exit 1
}

# 1. Verificar se rootfs existe e tem busybox
check_rootfs() {
    [ ! -d "$ROOTFS" ] && error "RootFS não existe em $ROOTFS"
    [ ! -x "$ROOTFS/bin/busybox" ] && error "Busybox não encontrado em $ROOTFS/bin/"
    
    log "RootFS verificado: $ROOTFS"
}

# 2. Verificar estado dos mounts essenciais
check_mounts() {
    local mounts="proc sys dev dev/pts"
    local missing=""
    
    for mount in $mounts; do
        mountpoint "$ROOTFS/$mount" >/dev/null 2>&1 || missing="$missing $mount"
    done
    
    [ -n "$missing" ] && {
        warn "Mounts pendentes:$missing"
        return 1
    }
    
    log "Todos mounts estão OK"
    return 0
}

# 3. Montar tudo necessário (idempotente)
mount_all() {
    warn "Montando sistemas de arquivos essenciais..."
    
    mountpoint -q "$ROOTFS/proc" || mount -t proc proc "$ROOTFS/proc"
    mountpoint -q "$ROOTFS/sys" || mount -t sysfs sysfs "$ROOTFS/sys"
    mountpoint -q "$ROOTFS/dev" || mount -t devtmpfs devtmpfs "$ROOTFS/dev"
    mountpoint -q "$ROOTFS/dev/pts" || mount -t devpts devpts "$ROOTFS/dev/pts" -o gid=5,mode=620
    mountpoint -q "$ROOTFS/tmp" || mount -t tmpfs tmpfs "$ROOTFS/tmp"
    
    # Bind mount do host resolv.conf (DNS)
    mountpoint -q "$ROOTFS/etc/resolv.conf" 2>/dev/null || {
        mkdir -p "$ROOTFS/etc"
        mount -t bind /etc/resolv.conf "$ROOTFS/etc/resolv.conf"
    }
    
    log "Todos mounts configurados!"
}

# 4. Desmontar tudo (seguro, ignora erros)
umount_all() {
    warn "Desmontando sistemas de arquivos..."
    
    {   # Agrupa comandos em bloco para lazy umount
        umount -l "$ROOTFS/dev/pts" 2>/dev/null || true
        umount -l "$ROOTFS/dev" 2>/dev/null || true
        umount -l "$ROOTFS/proc" 2>/dev/null || true
        umount -l "$ROOTFS/sys" 2>/dev/null || true
        umount -l "$ROOTFS/tmp" 2>/dev/null || true
        umount -l "$ROOTFS/etc/resolv.conf" 2>/dev/null || true
    }
    
    log "Todos mounts desmontados com segurança"
}

# 5. Entrar no chroot com shell especificado
enter_chroot() {
    local shell="$1"
    
    log "Entrando no chroot: $shell"
    echo "PID do chroot: $$" > "$PIDFILE"
    
    # Trap para cleanup automático na saída
    trap 'umount_all; rm -f "$PIDFILE"; log "Chroot encerrado limpo"; exit 0' INT TERM EXIT
    
    exec chroot "$ROOTFS" "$shell"
}

# 6. Executar comando único no chroot
run_command() {
    shift # Remove 'run' do argumento
    log "Executando no chroot: $*"
    
    mount_all
    chroot "$ROOTFS" /bin/busybox sh -c "$*"
    umount_all
}

# 7. Verificar status do chroot
status() {
    if [ -f "$PIDFILE" ]; then
        local pid=$(cat "$PIDFILE")
        if kill -0 "$pid" 2>/dev/null; then
            log "Chroot ativo (PID: $pid)"
        else
            warn "PID obsoleto encontrado, removendo..."
            rm -f "$PIDFILE"
        fi
    else
        echo "Nenhum chroot ativo"
    fi
}

# MAIN: Processar argumentos
main() {
    check_rootfs
    
    case "$1" in
        status|-s)
            status
            ;;
        run|-r)
            [ $# -ge 2 ] || error "Uso: $0 run 'comando'"
            run_command "$@"
            ;;
        check|-c)
            check_mounts && log "Tudo pronto para chroot!" || warn "Execute mounts primeiro"
            ;;
        mount|-m)
            mount_all
            ;;
        umount|-u)
            umount_all
            ;;
        ""|sh|bash)
            mount_all
            enter_chroot "${SHELL:-/bin/busybox sh}"
            ;;
        *)
            warn "Comando desconhecido: $1"
            echo "Uso:"
            echo "  $0                    # Shell interativo"
            echo "  $0 run 'ls -la'       # Comando único"
            echo "  $0 status             # Ver status"
            echo "  $0 mount              # Só montar"
            echo "  $0 umount             # Só desmontar"
            echo "  $0 check              # Verificar mounts"
            exit 1
            ;;
    esac
}

# Executar main
main "$@"