#!/bin/sh

# 🔥 ORQUESTRADOR MASTER - Construção completa Linux do zero
# ✅ Retomada automática | ✅ Logs rotativos | ✅ Dependências resolvidas
# ✅ Cores | ✅ Barra progresso | ✅ Validação final
set -euo pipefail

# Configuração
ROOTFS="/mnt/rootfs"
LOGDIR="$ROOTFS/logs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
export LOGFILE="$LOGDIR/build_$TIMESTAMP.log"

# Cores POSIX
RED='\u001B[0;31m'; GREEN='\u001B[0;32m'; YELLOW='\u001B[1;33m'; BLUE='\u001B[0;34m'
NC='\u001B[0m'; BOLD='\u001B[1m'

# Estado global
STATE_FILE="$ROOTFS/.build_state"
mkdir -p "$LOGDIR"

# Logging inteligente
log()   { echo "[$(date +%H:%M:%S)] $*" | tee -a "$LOGFILE"; }
ok()    { log "${GREEN}✓${NC} $*"; }
warn()  { log "${YELLOW}⚠${NC} $*"; }
error() { log "${RED}✗${NC} $*" >&2; exit 1; }

# Barra de progresso POSIX
progress() {
    local current=$1 total=$2
    local percent=$((current * 100 / total))
    local bar=$(printf '=%.0s' $(seq 1 $((percent / 2))))
    printf "
${BLUE}[%-${total}s] %d%%${NC}" "$bar" "$percent"
}

# Verificar estado (retomada)
get_status() {
    touch "$STATE_FILE"
    awk -v step="$1" '$1==step {print $2}' "$STATE_FILE" 2>/dev/null || echo "pending"
}

set_status() {
    grep -v "^$1 " "$STATE_FILE" 2>/dev/null > /tmp/state.tmp && mv /tmp/state.tmp "$STATE_FILE"
    echo "$1 done" >> "$STATE_FILE"
    log "[$1] ✅ Completo"
}

# Dependências em ordem DAG (grafo acíclico)
STAGES="
prepare_rootfs
build_toolchain
build_busybox  
build_base_libs
build_system_base
build_network
build_users
build_boot
final_test
"

# 1. Preparar rootfs
stage_prepare_rootfs() {
    [ "$(get_status prepare_rootfs)" = "done" ] && { log "prepare_rootfs já feito"; return; }
    
    log "🏗️  1/9 Preparando estrutura rootfs..."
    rm -rf "$ROOTFS" "$LOGDIR"
    mkdir -p "$ROOTFS"/{bin,sbin,lib{,64},usr/{bin,sbin,lib{,64}},dev,proc,sys,tmp,etc,var,src}
    
    # Dispositivos + arquivos mínimos
    mknod "$ROOTFS/dev/null" c 1 3 && chmod 666 "$ROOTFS/dev/null"
    cat > "$ROOTFS/etc/fstab" << 'EOF'
proc /proc proc defaults 0 0
sysfs /sys sysfs defaults 0 0
EOF
    
    cat > "$ROOTFS/build_env.sh" << EOF
export ROOTFS=$ROOTFS
export PATH=$ROOTFS/tools/bin:$PATH
export CC="$ROOTFS/tools/bin/x86_64-pc-linux-gnu-gcc"
EOF
    chmod +x "$ROOTFS/build_env.sh"
    
    set_status prepare_rootfs
}

# 2. Toolchain (30-60min)
stage_build_toolchain() {
    [ "$(get_status build_toolchain)" = "done" ] && return 0
    
    log "🔨 2/9 Construindo toolchain (30-60min)..."
    . "$ROOTFS/build_env.sh"
    
    cd "$ROOTFS/src"
    wget -q https://ftp.gnu.org/gnu/binutils/binutils-2.44.tar.xz
    tar xf binutils-2.44.tar.xz && cd binutils-2.44
    ./configure --prefix="$ROOTFS/tools" --target=x86_64-pc-linux-gnu && make -j$(nproc)
    make install && cd ../..
    
    set_status build_toolchain
}

# 3. Busybox (5min)
stage_build_busybox() {
    [ "$(get_status build_busybox)" = "done" ] && return 0
    
    log "🐣 3/9 Busybox..."
    . "$ROOTFS/build_env.sh"
    cd "$ROOTFS/src"
    wget -q https://busybox.net/downloads/busybox-1.36.1.tar.bz2
    tar xjf busybox-1.36.1.tar.bz2 && cd busybox-1.36.1
    make defconfig && make -j$(nproc) CONFIG_PREFIX="$ROOTFS"
    make install CONFIG_PREFIX="$ROOTFS"
    chmod +x "$ROOTFS/init"
    set_status build_busybox
}

# 4. Libs base (15min)
stage_build_base_libs() {
    [ "$(get_status build_base_libs)" = "done" ] && return 0
    
    log "📚 4/9 Bibliotecas base..."
    . "$ROOTFS/build_env.sh"
    cd "$ROOTFS/src"
    
    for lib in zlib-1.3.1 ncurses-6.4 openssl-3.2.1 readline-8.2; do
        wget -q "https://zlib.net/$lib.tar.gz" && tar xzf "$lib.tar.gz"
        cd "$lib" && ./configure --prefix="$ROOTFS/sysroot/usr" && make -j$(nproc) && make install
        cd ..
    done
    set_status build_base_libs
}

# 5. Sistema base (30min)
stage_build_system_base() {
    [ "$(get_status build_system_base)" = "done" ] && return 0
    
    log "🏛️  5/9 Coreutils + Bash..."
    . "$ROOTFS/build_env.sh"
    cd "$ROOTFS/src"
    
    for pkg in coreutils-9.5 bash-5.2.26; do
        wget -q "https://ftp.gnu.org/gnu/$pkg.tar.xz"
        tar xf "$pkg.tar.xz" && cd "${pkg#*-}"
        ./configure --prefix="$ROOTFS/usr" && make -j$(nproc) && make install
        cd ..
    done
    set_status build_system_base
}

# 6. Rede (10min)
stage_build_network() {
    [ "$(get_status build_network)" = "done" ] && return 0
    
    log "🌐 6/9 wget + network..."
    . "$ROOTFS/build_env.sh"
    cd "$ROOTFS/src"
    wget -q https://ftp.gnu.org/gnu/wget/wget-1.21.4.tar.gz
    tar xzf wget-1.21.4.tar.gz && cd wget-1.21.4
    ./configure --prefix="$ROOTFS/usr" && make -j$(nproc) && make install
    set_status build_network
}

# 7. Usuários (5min)
stage_build_users() {
    [ "$(get_status build_users)" = "done" ] && return 0
    
    log "👥 7/9 Shadow (usuários)..."
    . "$ROOTFS/build_env.sh"
    cd "$ROOTFS/src"
    wget -q https://github.com/shadow-maint/shadow/releases/download/v4.14.2/shadow-4.14.2.tar.xz
    tar xf shadow-4.14.2.tar.xz && cd shadow-4.14.2
    ./configure --prefix="$ROOTFS/usr" && make -j$(nproc) && make install
    set_status build_users
}

# 8. Boot (20min)
stage_build_boot() {
    [ "$(get_status build_boot)" = "done" ] && return 0
    
    log "⚙️  8/9 Kernel..."
    . "$ROOTFS/build_env.sh"
    cd "$ROOTFS/src"
    wget -q https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-6.12.tar.xz
    tar xf linux-6.12.tar.xz && cd linux-6.12
    make defconfig && make -j$(nproc) bzImage
    cp arch/x86/boot/bzImage "$ROOTFS/boot/vmlinuz"
    set_status build_boot
}

# 9. Teste final
stage_final_test() {
    log "🧪 9/9 Testes finais..."
    
    [ -x "$ROOTFS/bin/bash" ] && ok "Bash OK" || error "Bash falhou"
    [ -x "$ROOTFS/usr/bin/wget" ] && ok "Wget OK" || error "Wget falhou"
    [ -f "$ROOTFS/boot/vmlinuz" ] && ok "Kernel OK" || error "Kernel falhou"
    
    log "🎉 SISTEMA PRONTO! Execute: ./chroot_safe.sh"
    set_status final_test
}

# MAIN ORQUESTRADOR
main() {
    log "🚀 Iniciando construção Linux completa em $ROOTFS"
    log "Log: $LOGFILE"
    
    total_stages=$(echo "$STAGES" | wc -l)
    current=0
    
    for stage in $STAGES; do
        current=$((current + 1))
        progress $current $total_stages
        
        case $stage in
            prepare_rootfs) stage_prepare_rootfs ;;
            build_toolchain) stage_build_toolchain ;;
            build_busybox) stage_build_busybox ;;
            build_base_libs) stage_build_base_libs ;;
            build_system_base) stage_build_system_base ;;
            build_network) stage_build_network ;;
            build_users) stage_build_users ;;
            build_boot) stage_build_boot ;;
            final_test) stage_final_test ;;
        esac
    done
    
    progress $total_stages $total_stages
    echo "
${GREEN}🎉 CONSTRUÇÃO 100% CONCLUÍDA!${NC}"
    echo "📁 RootFS: $ROOTFS"
    echo "🐚 Entre: sudo ./chroot_safe.sh"
    echo "🧪 Teste: qemu-system-x86_64 -kernel $ROOTFS/boot/vmlinuz -initrd initramfs.gz"
}

# Trap para cleanup
trap 'error "Interrompido. Retome com: ./build_system.sh"' INT TERM

# EXECUTAR
main "$@"