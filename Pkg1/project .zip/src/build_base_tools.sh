#!/bin/sh
set -e

. /mnt/rootfs/build_env.sh
ROOTFS="/mnt/rootfs"
SRC="$ROOTFS/src"

# 1. WGET (essencial para baixar mais pacotes)
cd "$SRC"
wget https://ftp.gnu.org/gnu/wget/wget-1.21.4.tar.gz
tar xzf wget-1.21.4.tar.gz
cd wget-1.21.4
./configure --prefix="$ROOTFS/usr" --disable-nls
make -j$(nproc) && make install

# 2. SHADOW (usuários reais)
wget https://github.com/shadow-maint/shadow/releases/download/v4.14.2/shadow-4.14.2.tar.xz
tar xf shadow-4.14.2.tar.xz
cd shadow-4.14.2
./configure --prefix="$ROOTFS/usr" --without-selinux --disable-nls
make -j$(nproc) && make install

# 3. DHCP (rede básica)
wget https://roy.marples.name/downloads/dhcpcd/dhcpcd-10.0.8.tar.xz
tar xf dhcpcd-10.0.8.tar.xz
cd dhcpcd-10.0.8
./configure --prefix="$ROOTFS/usr" --disable-udev
make -j$(nproc) && make install

echo "✅ wget, shadow, dhcpcd instalados!"
echo "Agora rode: sudo ./chroot_safe.sh"
echo "Dentro: useradd teste, wget google.com"