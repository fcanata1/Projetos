#!/bin/sh
set -e

# Carrega ambiente toolchain
. /mnt/rootfs/build_env.sh

ROOTFS="/mnt/rootfs"
SRC="$ROOTFS/src"
SYSROOT="$ROOTFS/sysroot"
PARALLEL=$(nproc)

echo "Instalando bibliotecas base para compilar programas..."

cd "$SRC"

# 1. ZLIB (compressão, essencial para tudo)
wget https://zlib.net/zlib-1.3.1.tar.gz
tar xzf zlib-1.3.1.tar.gz
cd zlib-1.3.1
./configure --prefix="$SYSROOT/usr"
make -j$PARALLEL && make install
cd ..

# 2. NCURSES (interfaces TUI como top, htop)
wget https://ftp.gnu.org/gnu/ncurses/ncurses-6.4.tar.gz
tar xzf ncurses-6.4.tar.gz
cd ncurses-6.4
./configure --prefix="$SYSROOT/usr" --without-debug --without-shared --with-static
make -j$PARALLEL && make install
cd ..

# 3. OPENSSL (criptografia, SSL/TLS)
wget https://www.openssl.org/source/openssl-3.2.1.tar.gz
tar xzf openssl-3.2.1.tar.gz
cd openssl-3.2.1
./config --prefix="$SYSROOT/usr" --openssldir="$SYSROOT/usr/etc/ssl" no-shared
make -j$PARALLEL && make install
cd ..

# 4. READLINE (histórico bash)
wget https://ftp.gnu.org/gnu/readline/readline-8.2.tar.gz
tar xzf readline-8.2.tar.gz
cd readline-8.2
./configure --prefix="$SYSROOT/usr" --disable-shared --enable-static
make -j$PARALLEL && make install
cd ..

# 5. MAKE (GNU Make para builds)
wget https://ftp.gnu.org/gnu/make/make-4.4.tar.gz
tar xzf make-4.4.tar.gz
cd make-4.4
./configure --prefix="$ROOTFS/usr"
make -j$PARALLEL && make install
cd ..

echo "✅ Base instalada! Agora você pode compilar:"
echo "   - Bash, Coreutils, Findutils"
echo "   - Qualquer programa C/C++ com ./configure && make"