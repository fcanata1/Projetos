#!/bin/sh

# SysVinit completo + serviços essenciais para /mnt/rootfs
# Inclui init, inittab, runlevels, serviços padrão
set -euo pipefail

ROOTFS="/mnt/rootfs"
SRC="$ROOTFS/src"
INITDIR="$ROOTFS/etc/init.d"
PARALLEL=$(nproc)

. "$ROOTFS/build_env.sh" || error "Ambiente não encontrado"

log() { echo "[$(date +%H:%M:%S)] $*"; }
error() { echo "ERRO: $*" >&2; exit 1; }

# 1. Construir SysVinit (3.10)
build_sysvinit() {
    log "Construindo SysVinit 3.10..."
    cd "$SRC"
    wget -q https://github.com/slicer69/sysvinit/releases/download/3.10/sysvinit-3.10.tar.xz
    tar xf sysvinit-3.10.tar.xz
    cd sysvinit-3.10/src
    
    make -j$PARALLEL ROOT="$ROOTFS" D=1 CPPFLAGS="-I$ROOTFS/sysroot/usr/include"
    make ROOT="$ROOTFS" D=1 install
    
    cd ../man
    make ROOT="$ROOTFS" D=1 install.man
    cd ../src
    
    log "✅ SysVinit instalado"
}

# 2. Configurar inittab completo
setup_inittab() {
    log "Configurando /etc/inittab..."
    cat > "$ROOTFS/etc/inittab" << 'EOF'
# Runlevels
id:3:initdefault:

# Global
si::sysinit:/etc/init.d/rcS
l0:0:wait:/etc/init.d/rc 0
l1:1:wait:/etc/init.d/rc 1
l2:2:wait:/etc/init.d/rc 2
l6:6:wait:/etc/init.d/rc 6

# Console
c1:2345:respawn:/sbin/getty 38400 tty1
c2:2345:respawn:/sbin/getty 38400 tty2

# Ctrl+Alt+Del
ca::ctrlaltdel:/sbin/reboot

# Shutdown
su:S016:once:/sbin/umount -a -r
um:015:once:umount -a -r
EOF
}

# 3. Criar scripts de init essenciais
create_services() {
    log "Criando serviços essenciais..."
    mkdir -p "$INITDIR"
    
    # rcS (boot inicial)
    cat > "$INITDIR/rcS" << 'EOF'
#!/bin/sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
mount -a
hostname localhost
log "Sistema iniciado"
EOF
    
    # rc (runlevels 0-6)
    cat > "$INITDIR/rc" << 'EOF'
#!/bin/sh
[ $# -eq 0 ] && exit 1
RUNLEVEL="$1"

case "$RUNLEVEL" in
    0|6) log "Shutdown/Reboot" ;;
    1)   log "Single user mode" ;;
    2|3|4|5) log "Multiuser mode" ;;
esac
EOF
    
    chmod +x "$INITDIR"/rc{S,}
    
    # Serviços padrão
    for svc in networking devfsd; do
        cat > "$INITDIR/$svc" << EOF
#!/bin/sh
case "$1" in
    start) log "Starting $svc" ;;
    stop)  log "Stopping $svc" ;;
    *)     echo "Usage: $0 {start|stop}" ;;
esac
EOF
        chmod +x "$INITDIR/$svc"
    done
}

# 4. Symlinks runlevels
setup_runlevels() {
    log "Configurando runlevels 0-6..."
    for level in 0 1 2 3 4 5 6; do
        mkdir -p "$ROOTFS/etc/rc${level}.d"
        ln -s ../init.d/rc "$ROOTFS/etc/rc${level}.d/rc"
    done
}

# EXECUTAR
build_sysvinit
setup_inittab
create_services
setup_runlevels

log "✅ SysVinit + serviços essenciais instalados!"
log "Teste: chroot_safe.sh run '/sbin/init 3'"