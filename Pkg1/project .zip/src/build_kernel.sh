#!/bin/sh
set -e

# Carrega ambiente toolchain
[ -f /mnt/rootfs/build_env.sh ] && . /mnt/rootfs/build_env.sh

ROOTFS="/mnt/rootfs"
SRC="$ROOTFS/src"
KERNEL_VER="6.12.0"  # Última stable
PARALLEL=$(nproc)

echo "Construindo Kernel $KERNEL_VER..."

cd "$SRC"

# 1. Baixar kernel
wget https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-$KERNEL_VER.tar.xz
tar xf linux-$KERNEL_VER.tar.xz
cd linux-$KERNEL_VER

# 2. Configuração mínima para initramfs
cp /boot/config-$(uname -r) .config  # Base do host
make olddefconfig
make menuconfig << 'EOF'
General setup  --->
  [*] Initramfs source files
  (/mnt/rootfs) Initramfs source files
EOF

# 3. Compilar kernel + modules
make -j$PARALLEL bzImage
make -j$PARALLEL modules

# 4. Instalar em rootfs
make modules_install INSTALL_MOD_PATH="$ROOTFS"
cp -a arch/x86/boot/bzImage "$ROOTFS/boot/vmlinuz"

echo "Kernel pronto em $ROOTFS/boot/vmlinuz!"