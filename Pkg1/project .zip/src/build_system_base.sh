#!/bin/sh

# Script POSIX para construir BASE do sistema (coreutils, bash, util-linux)
# Executa via chroot_safe.sh para compilação nativa segura
set -e

# Carrega ambiente (deve existir)
[ -f /mnt/rootfs/build_env.sh ] && . /mnt/rootfs/build_env.sh || {
    echo "ERRO: Execute prepare_rootfs.sh primeiro!"
    exit 1
}

ROOTFS="/mnt/rootfs"
SRC="$ROOTFS/src"
PARALLEL=$(nproc)

# Lista de pacotes com suas dependências resolvidas
PACKAGES="
coreutils-9.5
bash-5.2.26
util-linux-2.40.2
findutils-4.9.0
grep-3.11
sed-4.9
tar-1.35
file-5.45
"

echo "=== Construindo BASE do Sistema ==="
echo "Pacotes: $PACKAGES"
echo "Tempo estimado: 30-45min"

cd "$SRC"

# 1. COREUTILS (ls, cp, mv, rm, cat, etc - 200+ comandos essenciais)
build_coreutils() {
    local ver="9.5"
    rm -rf coreutils-$ver
    wget https://ftp.gnu.org/gnu/coreutils/coreutils-$ver.tar.xz
    tar xf coreutils-$ver.tar.xz
    cd coreutils-$ver
    
    ./configure \
        --prefix="$ROOTFS/usr" \
        --disable-nls \
        --enable-no-install-program=kill,uptime \
        --libdir="$ROOTFS/usr/lib"
    
    make -j$PARALLEL && make install
    cd ..
    echo "✅ Coreutils $ver instalado (ls, cp, mv, rm, etc)"
}

# 2. BASH (shell POSIX completo com histórico)
build_bash() {
    local ver="5.2.26"
    rm -rf bash-$ver
    wget https://ftp.gnu.org/gnu/bash/bash-$ver.tar.gz
    tar xzf bash-$ver.tar.gz
    cd bash-$ver
    
    ./configure \
        --prefix="$ROOTFS/usr" \
        --without-bash-malloc \
        --disable-nls \
        --libdir="$ROOTFS/usr/lib"
    
    make -j$PARALLEL && make install
    ln -sf bash "$ROOTFS/bin/bash"
    cd ..
    echo "✅ Bash $ver instalado (/bin/bash)"
}

# 3. UTIL-LINUX (mount, fdisk, ps, etc)
build_util_linux() {
    local ver="2.40.2"
    rm -rf util-linux-$ver
    wget https://mirrors.edge.kernel.org/pub/linux/utils/util-linux/v${ver%.*}/util-linux-$ver.tar.xz
    tar xf util-linux-$ver.tar.xz
    cd util-linux-$ver
    
    ./configure \
        --prefix="$ROOTFS/usr" \
        --disable-all-programs \
        --enable-mount \
        --enable-losetup \
        --enable-fsck \
        --enable-fdisk \
        --enable-sfdisk \
        --enable-ps \
        --enable-libmount \
        --enable-libuuid \
        --disable-use-tty-group \
        --disable-nls
    
    make -j$PARALLEL && make install
    cd ..
    echo "✅ Util-linux $ver (mount, ps, fdisk)"
}

# 4. FINDUTILS + GREP + SED + TAR + FILE
build_essentials() {
    # findutils
    local ver="4.9.0"
    rm -rf findutils-$ver
    wget https://ftp.gnu.org/gnu/findutils/findutils-$ver.tar.gz
    tar xzf findutils-$ver.tar.gz
    cd findutils-$ver
    ./configure --prefix="$ROOTFS/usr" --disable-nls
    make -j$PARALLEL && make install
    cd ..

    # grep
    ver="3.11"
    rm -rf grep-$ver
    wget https://ftp.gnu.org/gnu/grep/grep-$ver.tar.xz
    tar xf grep-$ver.tar.xz
    cd grep-$ver
    ./configure --prefix="$ROOTFS/usr"
    make -j$PARALLEL && make install
    cd ..

    # sed
    ver="4.9"
    rm -rf sed-$ver
    wget https://ftp.gnu.org/gnu/sed/sed-$ver.tar.xz
    tar xf sed-$ver.tar.xz
    cd sed-$ver
    ./configure --prefix="$ROOTFS/usr" --disable-nls
    make -j$PARALLEL && make install
    cd ..

    # tar
    ver="1.35"
    rm -rf tar-$ver
    wget https://ftp.gnu.org/gnu/tar/tar-$ver.tar.xz
    tar xf tar-$ver.tar.xz
    cd tar-$ver
    ./configure --prefix="$ROOTFS/usr"
    make -j$PARALLEL && make install
    cd ..

    # file
    ver="5.45"
    rm -rf file-$ver
    wget https://astronemo.github.io/libmagic/file-$ver.tar.xz
    tar xf file-$ver.tar.xz
    cd file-$ver
    ./configure --prefix="$ROOTFS/usr"
    make -j$PARALLEL && make install
    cd ..

    echo "✅ Ferramentas essenciais instaladas"
}

# EXECUTAR EM ORDEM
build_coreutils
build_essentials  
build_util_linux
build_bash

# 5. Atualizar symlinks essenciais
ln -sf usr/bin/* "$ROOTFS/bin/"
ln -sf usr/sbin/* "$ROOTFS/sbin/" 2>/dev/null || true

# 6. Teste final via chroot_safe
echo ""
echo "=== TESTE FINAL ==="
if [ -x "./chroot_safe.sh" ]; then
    ./chroot_safe.sh run "ls -la /bin/ | wc -l"
    ./chroot_safe.sh run "bash --version"
    ./chroot_safe.sh run "ps --version"
    ./chroot_safe.sh run "mount --version"
else
    echo "Crie chroot_safe.sh primeiro para testes"
fi

echo ""
echo "✅ === BASE DO SISTEMA PRONTA ==="
echo "Agora você tem:"
echo "   • 200+ comandos coreutils (ls, cp, mv, rm...)"
echo "   • Bash 5.2 com histórico"
echo "   • mount, ps, fdisk (util-linux)"
echo "   • find, grep, sed, tar, file"
echo ""
echo "Próximo: build_network.sh (wget, curl, sshd)"