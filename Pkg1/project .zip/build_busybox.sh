#!/bin/sh

# Script POSIX para compilar Busybox estático para /mnt/rootfs
set -e

# Carrega ambiente da toolchain (deve existir do prepare_rootfs.sh)
[ -f /mnt/rootfs/build_env.sh ] && . /mnt/rootfs/build_env.sh || {
    echo "ERRO: Execute prepare_rootfs.sh primeiro!"
    exit 1
}

ROOTFS="/mnt/rootfs"
SRC="$ROOTFS/src"
BUSYBOX_VER="1.36.1"
PARALLEL=$(nproc)

echo "Construindo Busybox $BUSYBOX_VER para $ROOTFS..."

cd "$SRC"

# 1. Baixar e extrair Busybox latest
rm -rf busybox-$BUSYBOX_VER
wget -N https://busybox.net/downloads/busybox-$BUSYBOX_VER.tar.bz2
bunzip2 -c busybox-$BUSYBOX_VER.tar.bz2 | tar xf -
cd busybox-$BUSYBOX_VER

# 2. Configuração para static build (sem dependências externas)
make defconfig
make menuconfig << 'EOF'

Busybox Settings  --->
  Build Options  --->
    [*] Build BusyBox as a static binary (no shared libs)
    (y) Leave out LFS support
    (y) Avoids creating huge static binaries (no mmap support)
EOF

# 3. Compilar com toolchain cross
make clean
make -j$PARALLEL CC="$CC" CROSS_COMPILE="$CROSS_COMPILE"

# 4. Instalar em staging
make install CONFIG_PREFIX="$ROOTFS/_install"

# 5. Copiar para rootfs final
cd "$ROOTFS"
rm -rf bin sbin lib lib64 usr
cp -a _install/* .
rm bin/busybox  # Remove binário único, mantém symlinks

# 6. Criar init script POSIX
cat > init << 'EOF'
#!/bin/sh
mountpoint -q /proc || mount -t proc proc /proc
mountpoint -q /sys || mount -t sysfs sysfs /sys
mountpoint -q /dev || mount -t devtmpfs devtmpfs /dev
mountpoint -q /dev/pts || mount -t devpts devpts /dev/pts

echo "Busybox initramfs iniciado!"
echo "Digite 'help' para comandos disponíveis"

exec /bin/sh
EOF
chmod +x init

# 7. Configurar inittab mínimo
mkdir -p etc
cat > etc/inittab << 'EOF'
::sysinit:/init
::respawn:/sbin/getty 38400 console
::ctrlaltdel:/sbin/reboot
::shutdown:/bin/umount -a -r
EOF

# 8. Teste final
echo "Busybox instalado! Testando..."
if chroot . bin/busybox sh -c 'echo OK; ls /bin'; then
    echo "✅ Busybox funcional!"
else
    echo "❌ Erro no Busybox"
    exit 1
fi

echo "Busybox pronto em $ROOTFS!"
echo "Para testar: chroot /mnt/rootfs /init"