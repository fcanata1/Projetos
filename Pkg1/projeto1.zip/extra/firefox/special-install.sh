#!/bin/sh
# Firefox special-install LFS

section "🚀 FIREFOX INSTALL ESPECIAL (LFS)"

cd "$CACHE/build/firefox/obj-lfs"

# Instala binários principais
make DESTDIR="$DESTDIR" install

# Desktop entry
mkdir -p "$DESTDIR/usr/share/applications"
cat > "$DESTDIR/usr/share/applications/firefox.desktop" << 'EOF'
[Desktop Entry]
Name=Firefox
Comment=Web Browser
Exec=/usr/lib/firefox/firefox %u
Icon=firefox
Terminal=false
Type=Application
Categories=Network;WebBrowser;
MimeType=text/html;text/xml;application/xhtml+xml;...
EOF

# Icons
mkdir -p "$DESTDIR/usr/share/icons/hicolor/128x128/apps"
ln -sfv /usr/lib/firefox/browser/chrome/icons/default/default128.png \
        "$DESTDIR/usr/share/icons/hicolor/128x128/apps/firefox.png"

# Symlink global
ln -sfv /usr/lib/firefox/firefox "$DESTDIR/usr/bin/firefox"

# Profile dirs
install -v -d -m755 "$DESTDIR/usr/lib/firefox/defaults/profile"
install -v -m644 "$CACHE/build/firefox/browser/defaults/profile/prefs.js" \
                 "$DESTDIR/usr/lib/firefox/defaults/profile/" 2>/dev/null || true

log "${GREEN}✅ Firefox instalado em /usr/lib/firefox${NC}"