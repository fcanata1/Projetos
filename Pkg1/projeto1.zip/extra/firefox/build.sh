#!/bin/sh
# Firefox build LFS otimizado - MACH + CCACHE

set -e

section "🔧 Configurando Firefox para LFS"

export MOZCONFIG="$CACHE/build/firefox/mozconfig"
export MOZ_NOSPAM=1
export MOZ_TELEMETRY_REPORT=0
export MOZ_SERVICES_HEALTHREPORT=0

cat > "$MOZCONFIG" << 'EOF'
# Mozilla LFS Optimized
ac_add_options --prefix=/usr
ac_add_options --libdir=/usr/lib/firefox
ac_add_options --enable-optimize="-O2 -pipe"
ac_add_options --enable-release
ac_add_options --disable-debug
ac_add_options --disable-debug-symbols
ac_add_options --disable-tests
ac_add_options --disable-updater
ac_add_options --disable-crashreporter
ac_add_options --disable-necko-wifi
ac_add_options --enable-system-ffi
ac_add_options --enable-system-hunspell
ac_add_options --enable-system-pixman
ac_add_options --enable-system-cairo
ac_add_options --enable-system-icu
ac_add_options --enable-system-ogg
ac_add_options --enable-system-png
ac_add_options --enable-system-webp
ac_add_options --enable-system-zlib
ac_add_options --enable-system-sqlite
ac_add_options --enable-system-harfbuzz
ac_add_options --enable-system-graphite2
ac_add_options --with-system-nspr
ac_add_options --with-system-nss
ac_add_options --with-system-png
ac_add_options --with-system-jpeg
ac_add_options --without-system-libvpx
mk_add_options MOZ_OBJDIR="@TOPSRCDIR@/obj-lfs"
EOF

# Build com MACH (paralelo)
cd "$CACHE/build/firefox"
python3 ./mach build --jobs=$(nproc)