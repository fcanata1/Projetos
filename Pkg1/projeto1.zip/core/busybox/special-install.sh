#!/bin/sh
# special-install.sh - BusyBox instalação LFS perfeita

section "📦 BUSYBOX INSTALL ESPECIAL (LFS)"

cd "$CACHE/build/busybox"

# Cria busybox padrão (estático)
cp busybox "$DESTDIR/bin/busybox"

# Links simbólicos LFS essenciais
install -d "$DESTDIR/{sbin,usr/{sbin,bin},bin}"
cd "$DESTDIR/bin"

# Binários essenciais
for bin in busybox ash sh; do
    ln -sf busybox "$bin"
done

# Utilitários essenciais LFS
for util in ls cat cp mv mkdir rmdir rm touch ln chmod chown chgrp \
            mkdir rmdir mount umount ps free df ifconfig ping \
            grep sed awk tar gzip gunzip bunzip2 bzcat \
            find xargs chmod chown date ln ls mkdir mknod mv \
            rm rmdir sync test dmesync basename dirname; do
    ln -sf busybox "$util" 2>/dev/null || true
done

# /sbin essenciais
cd "$DESTDIR/sbin"
for util in switch_root init poweroff reboot halt fdisk mkfs; do
    ln -sf /bin/busybox "$util" 2>/dev/null || true
done

log "${GREEN}✅ BusyBox instalado com $(find "$DESTDIR" -type l | wc -l) symlinks${NC}"