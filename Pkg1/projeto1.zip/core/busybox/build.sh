#!/bin/sh

set -e

section "🔧 Configurando BusyBox para LFS"

make defconfig

# Flags LFS otimizadas
sed -i 's|^CONFIG_EXTRA_CFLAGS=.*|CONFIG_EXTRA_CFLAGS=" -Os -pipe -fno-strict-aliasing"|' .config
sed -i 's|^CONFIG_STATIC[^=]*=.*|CONFIG_STATIC=y|' .config
sed -i 's|^CONFIG_FEATURE_INSTALLER[^=]*=.*|CONFIG_FEATURE_INSTALLER=y|' .config

make -j$(nproc) V=1 || exit 1