#!/bin/sh
# Binutils LFS - Passo-a-passo completo

set -e

BUILD_DIR="build"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

log "🔧 Configurando binutils para LFS"
../configure \
    --prefix=/usr \
    --enable-gold \
    --enable-ld=default \
    --enable-plugins \
    --enable-shared \
    --disable-nls \
    --disable-werror \
    --with-system-zlib

log "🔨 Compilando (pode demorar)"
make tooldir=/usr -j$(nproc)

log "✅ Binutils Passo 1 concluído"