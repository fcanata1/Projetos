#!/bin/sh

set -e

section "🔧 Configurando SysVinit"

# Config autotools LFS
./configure \
    CFLAGS="-Os -pipe -fomit-frame-pointer" \
    --prefix=/usr \
    --sysconfdir=/etc \
    --localstatedir=/var \
    --enable-clobber \
    --enable-file-lock \
    --enable-killall \
    --disable-mknod \
    --disable-last

make -j$(nproc) V=1 || exit 1