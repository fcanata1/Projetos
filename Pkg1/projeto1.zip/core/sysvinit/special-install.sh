#!/bin/sh
# special-install.sh - SysVinit LFS perfeita

section "🚀 SYSVINIT INSTALL ESPECIAL (LFS)"

cd "$CACHE/build/sysvinit"

# Binários principais
install -v -m755 init       "$DESTDIR/sbin/init"
install -v -m755 halt        "$DESTDIR/sbin/halt"
install -v -m755 killall5    "$DESTDIR/usr/bin/killall5"
install -v -m755 poweroff    "$DESTDIR/sbin/poweroff"
install -v -m755 reboot      "$DESTDIR/sbin/reboot"
install -v -m755 runlevel    "$DESTDIR/sbin/runlevel"
install -v -m755 shutdown    "$DESTDIR/sbin/shutdown"

# Man pages essenciais
install -v -m644 src/init.8  "$DESTDIR/usr/share/man/man8/init.8"
install -v -m644 src/halt.8  "$DESTDIR/usr/share/man/man8/halt.8"

# Symlinks essenciais
ln -sfv /sbin/init           "$DESTDIR/sbin/rc"
ln -sfv /usr/bin/killall5    "$DESTDIR/usr/bin/pidof"

# Init DIRS LFS
install -v -m755 -d          "$DESTDIR/etc/init.d"
install -v -m755 -d          "$DESTDIR/etc/rc.d"
install -v -m644 src/initttab "$DESTDIR/etc/inittab"

# Default inittab LFS
cat > "$DESTDIR/etc/inittab" << 'EOF'
::sysinit:/etc/init.d/rcS
::respawn:/sbin/getty 38400 console
::ctrlaltdel:/sbin/shutdown -t3 -r now
EOF

log "${GREEN}✅ SysVinit instalado${NC}"