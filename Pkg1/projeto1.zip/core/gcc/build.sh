#!/bin/sh
# GCC LFS Completo - Passo-a-passo oficial

set -e

log "🚀 Construindo GCC-14.2.0 para LFS"

# ========================================
# PASSO 1: Preparar dependências internas
# ========================================
if [ ! -d "mpfr" ]; then
    log "📥 Baixando dependências internas GCC..."
    for dep in mpfr gmp mpc; do
        tar xf "../$dep"*.tar* || true
        mv "$dep"-* "mpfr-$dep" 2>/dev/null || true
    done
fi

# ========================================
# PASSO 2: Build out-of-source
# ========================================
BUILD_DIR="build"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

log "🔧 Configurando GCC para LFS final..."
../configure \
    --prefix=/usr \
    --enable-shared \
    --enable-threads=posix \
    --enable-tls \
    --enable-__cxa_atexit \
    --enable-clocale=gnu \
    --enable-languages=c,c++ \
    --disable-multilib \
    --disable-bootstrap \
    --disable-libstdcxx-pch \
    LD=ld

log "🔨 Compilando GCC (20-40min)..."
make -j$(nproc)

log "✅ GCC Passo 2 concluído"