#!/bin/sh
# special-install.sh - Instalação KERNEL 100% pkg-compatível

section "🚀 KERNEL INSTALL ESPECIAL"

# Kernel image
cp -v "$CACHE/build/linux/arch/x86/boot/bzImage" \
      "$DESTDIR/boot/vmlinuz-linux" || \
cp -v "$CACHE/build/linux/vmlinuz" "$DESTDIR/boot/vmlinuz-linux"

# System.map e config
cp -v "$CACHE/build/linux/System.map" "$DESTDIR/boot/System.map-linux"
cp -v "$CACHE/build/linux/.config"    "$DESTDIR/boot/config-linux"

# Módulos (estrutura correta)
version=$(make -C "$CACHE/build/linux" kernelrelease 2>/dev/null | head -1)
[ -n "$version" ] || version="$version"  # Fallback

install -d "$DESTDIR/lib/modules/$version"
cp -a "$CACHE/build/linux/Module.symvers" "$DESTDIR/lib/modules/$version/" 2>/dev/null || true
install -d "$DESTDIR/lib/modules/$version/build"
rsync -a "$CACHE/build/linux/scripts/" "$DESTDIR/lib/modules/$version/build/"

# Gera dependências dos módulos
(cd "$DESTDIR/lib/modules/$version" && 
 depmod -a -b "$DESTDIR" "$version" 2>/dev/null || true)

log "${GREEN}✅ Kernel $version instalado${NC}"