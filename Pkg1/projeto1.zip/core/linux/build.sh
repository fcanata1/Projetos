#!/bin/sh

# NÃO usa DESTDIR - pkg gerencia isso
make mrproper
make defconfig

# Build SEM install (pkg faz depois)
make -j$(nproc) V=1 bzImage modules cpio firmware || exit 1

# Gera arquivos essenciais SEM instalar
cp -v arch/x86/boot/bzImage      tmp-vmlinuz
cp -v System.map                 tmp-System.map
cp -v .config                    tmp-config